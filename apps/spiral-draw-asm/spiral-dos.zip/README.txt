Spiral Draw ASM for DOS

Extract both files to a folder. In DOSBox, mount the extracted
folder as C:, switch to C:, and run SPIRAL.COM. For example:

  mount c "C:\path\to\spiral"
  c:
  spiral

The spiral draws automatically. Space restarts it and Escape
returns to the DOS prompt.

Source: https://github.com/netcodermike/spiral-draw-asm
Play online: https://surfingcoder.com/apps/spiral-draw-asm/
